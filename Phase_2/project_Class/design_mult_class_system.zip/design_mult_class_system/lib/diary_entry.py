class DiaryEntry:
    
    def __init__(self, title, contents):
        self.title = title
        self.contents = contents


#     def add_entry(self, date, entry):
#         self.entries[entry.date] = entry.content
    
#     def get_entries(self):
#         return [DiaryEntry(date, None, content) for date, content in self.entries.items()]
        

#     def read_entry(self, date):
#         return self.entries.get(date, "No entry found for this date.")


#     def select_entries_for_reading(self, available_time, words_per_minute):
#         pass
#         # Select entries that can be read in the given time

#     def extract_phone_numbers(self):
#         pass
# class DiaryEntry:
#     def __init__(self, date, title, content):
#         self.date = date
#         self.title = title
#         self.content = content


# def count_words


# def reading_time

# def reading_chunk 
