
from lib.diary_entry import *
from datetime import date

# def test_extracting_phone_numbers():
#     content = "my mobile no 07599564000."
#     entry = DiaryEntry(date.today(), "Contact Info", content)

#     assert entry.extract_phone_numbers() == ["0759956400"]