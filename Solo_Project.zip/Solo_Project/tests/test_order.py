
from lib.dish import * 
from lib.menu import * 
from lib.order import * 

import pytest

class Order:
    def __init__(self):
        self.selections = {}

    def add_to_order(self, dish, quantity):
        self.selections[dish] = quantity

    def calculate_total(self):
        return sum(dish.price * quantity for dish, quantity in self.selections.items())

    def generate_receipt(self):
        for dish, quantity in self.selections.items():
            print(f"{quantity}x {dish.name} - £{dish.price} each")
        print(f"Total: £{self.calculate_total()}")



   