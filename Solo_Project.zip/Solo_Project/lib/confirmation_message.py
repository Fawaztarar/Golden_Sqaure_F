from twilio.rest import Client
import os

class Order:
    # ... other methods ...

    def send_confirmation_text(self, recipient_number, message):
        account_sid = os.environ['TWILIO_ACCOUNT_SID']
        auth_token = os.environ['TWILIO_AUTH_TOKEN']
        twilio_number = os.environ['TWILIO_PHONE_NUMBER']

        client = Client(account_sid, auth_token)
        message = client.messages.create(
            to=recipient_number,
            from_=twilio_number,
            body=message
        )
        return message.sid  # Returns message SID for confirmation

# Example usage
order = Order()
confirmation_message = "Your order is confirmed for delivery at 5 PM."
order.send_confirmation_text("+1234567890", confirmation_message)